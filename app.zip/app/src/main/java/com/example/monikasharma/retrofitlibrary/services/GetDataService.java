package com.example.monikasharma.retrofitlibrary.services;

import com.example.monikasharma.retrofitlibrary.model.RetroPhoto;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by monika.sharma on 24-09-2018.
 */

public interface GetDataService {
/*Annotations on the interface methods and its parameters indicate how a request will be handled*/
    @GET("/photos")
    Call<List<RetroPhoto>> getAllPhotos();
}
